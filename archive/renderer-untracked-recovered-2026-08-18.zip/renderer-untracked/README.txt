RECOVERED, AND NOT NECESSARILY IDENTICAL. Read this before using them.

These four files lived at src/renderer/src/rendering/debug/ in refii-clean and were NEVER
COMMITTED. The archive zips were built from `git ls-files`, which by definition lists only
tracked files, so they were not captured — and the directory removal deleted them.

The copies here are from the OLD tree, /home/loreaxe/Fable 2/refii, at their PRE-MERGE paths:

  src/renderer/src/runtime/plume/fable/debug/fable_renderdoc_capture.cpp
  src/renderer/src/runtime/plume/fable/debug/fable_renderdoc_draw_targets.cpp
  src/renderer/src/runtime/plume/fable/debug/fable_resource_debug_snapshot.cpp
  src/renderer/src/runtime/renderdoc_debugger.cpp

The refii-clean copies had been MOVED to a different directory, so they had at least different
include paths and may have carried edits that exist nowhere else. Treat these as the nearest
surviving version, not as the deleted files.

Everything else in the renderer archive is the committed state and is exact.
