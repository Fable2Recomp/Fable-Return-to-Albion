AppImage / Flatpak packaging — ARCHIVED, retired 2026-08-18.

These packaged the STANDALONE `refii` executable and the ImGui launcher, both retired when
Godot became the shell. The AppImage rule hard-required `TARGET refii` and
REFII_BUILD_LAUNCHER=ON, so it could not outlive them.

The appimagetool-x86_64/aarch64 binaries are NOT in this zip: they are prebuilt third-party
tools, ~28 MB, and are still tracked in git at packaging/appimage/.

To restore: paste the blocks back into CMakeLists.txt and turn REFII_BUILD_APPIMAGE
(and REFII_BUILD_LAUNCHER / REFII_BUILD_STANDALONE) back ON.
